import './footer.css'

function Footer() {
    return (  
        <div className="Footer">
            <div className="footer-section">
                <h3 className='site-name'>Zamon Parfum</h3>
                <p>Development site by Rajabov Amirbek</p>
                <div className="social-networks">
                    <span className='social-items'>
                    <a href="">
                        <i class="ri-telegram-fill"></i>
                        <p className="social-name">Telegram</p>                            
                    </a>
                    </span>
                    <span className='social-items'>
                    <a href="">
                        <i class="ri-instagram-fill"></i>
                        <p className="social-name">instagram</p>                            
                    </a>
                    </span>
                    <span className='social-items'>
                    <a href="">
                        <i class="ri-youtube-fill"></i>
                        <p className="social-name">You Tube</p>                            
                    </a>

                    </span>
                </div>
            </div>
        </div>
    );
}

export default Footer;