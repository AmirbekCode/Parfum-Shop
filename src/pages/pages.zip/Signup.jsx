import React from 'react';

function SignUp() {
    return ( 
        <div>
            
        </div>
     );
}

export default SignUp;