import React from 'react';
import Helmet from '../components/Helmet/Helmet'
function Shop() {
    return ( 
            <Helmet title="Do'kon"></Helmet>
     );
}

export default Shop;
