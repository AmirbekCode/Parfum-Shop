import React from 'react';
import Helmet from '../components/Helmet/Helmet'
function Cart() {
    return ( 
        <div>
            <Helmet title="Cart"></Helmet>
        </div>
     );
}

export default Cart;