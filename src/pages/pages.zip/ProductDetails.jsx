import React from 'react';

function ProductDetails() {
    return ( 
        <div>
            
        </div>
     );
}

export default ProductDetails;