import React from 'react';

function Checkout() {
    return (  

        <div>
            checkoko
        </div>
    );
}

export default Checkout;